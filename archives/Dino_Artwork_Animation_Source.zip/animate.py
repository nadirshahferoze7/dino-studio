import cv2, numpy as np, math, subprocess, pathlib
from PIL import Image
p=pathlib.Path(__file__).parent
src=np.asarray(Image.open(p/'approved_hero.png').convert('RGB').resize((720,720),Image.Resampling.LANCZOS))
H,W=src.shape[:2]; y,x=np.mgrid[:H,:W].astype(np.float32); X=x/W;Y=y/H
# Spatial envelopes: deform original art without drawing replacement geometry.
# Local movement is feathered into the neck/body, with feet held still.
head=np.exp(-(((X-.55)/.27)**4+((Y-.23)/.235)**4))*np.clip((.51-Y)/.13,0,1)
body=np.exp(-(((X-.51)/.25)**4+((Y-.58)/.24)**4))*np.clip((.91-Y)/.16,0,1)
tail=np.exp(-(((X-.24)/.15)**4+((Y-.64)/.135)**4))
# Encoding deterministic frames using CPU only.
cmd=['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r','30','-i','-','-an','-c:v','libx264','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(p/'Dino_Artwork_Motion.mp4')]
proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
frames=[]
for i in range(180):
 t=i/30; breath=math.sin(2*math.pi*t/2.6); gesture=math.sin(2*math.pi*t/6); nod=math.sin(2*math.pi*t/3)
 # Head inclination around a neck pivot; small enough to protect face shape.
 angle=.038*gesture; dx=-(y-.37*H)*angle*head + 1.1*breath*body; dy=(x-.55*W)*angle*head + 3.0*nod*head + 2.1*breath*body + 5.5*math.sin(2*math.pi*t/2.8+.3)*tail
 dx+=2.6*breath*(X-.5)*body
 out=cv2.remap(src,(x-dx).astype('float32'),(y-dy).astype('float32'),cv2.INTER_CUBIC,borderMode=cv2.BORDER_REFLECT_101)
 proc.stdin.write(out.tobytes())
 if i%5==0: frames.append(Image.fromarray(out).resize((430,430),Image.Resampling.LANCZOS))
proc.stdin.close(); assert proc.wait()==0
frames[0].save(p/'Dino_Artwork_Motion.gif',save_all=True,append_images=frames[1:],duration=167,loop=0,optimize=True)
